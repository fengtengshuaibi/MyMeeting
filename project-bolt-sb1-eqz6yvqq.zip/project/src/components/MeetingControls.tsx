import React from 'react';
import { Mic, MicOff, Video as VideoIcon, VideoOff, Monitor, Phone } from 'lucide-react';
import { useMeetingStore } from '../store/meeting';
import { cn } from '../lib/utils';

export function MeetingControls() {
  const { isMuted, isVideoOn, isScreenSharing, toggleMute, toggleVideo, toggleScreenShare } = useMeetingStore();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900 bg-opacity-90 px-6 py-4">
      <div className="flex items-center justify-center space-x-6">
        <button
          onClick={toggleMute}
          className={cn(
            "p-4 rounded-full transition-colors",
            isMuted ? "bg-red-500 hover:bg-red-600" : "bg-gray-700 hover:bg-gray-600"
          )}
        >
          {isMuted ? (
            <MicOff className="w-6 h-6 text-white" />
          ) : (
            <Mic className="w-6 h-6 text-white" />
          )}
        </button>

        <button
          onClick={toggleVideo}
          className={cn(
            "p-4 rounded-full transition-colors",
            !isVideoOn ? "bg-red-500 hover:bg-red-600" : "bg-gray-700 hover:bg-gray-600"
          )}
        >
          {!isVideoOn ? (
            <VideoOff className="w-6 h-6 text-white" />
          ) : (
            <VideoIcon className="w-6 h-6 text-white" />
          )}
        </button>

        <button
          onClick={toggleScreenShare}
          className={cn(
            "p-4 rounded-full transition-colors",
            isScreenSharing ? "bg-green-500 hover:bg-green-600" : "bg-gray-700 hover:bg-gray-600"
          )}
        >
          <Monitor className="w-6 h-6 text-white" />
        </button>

        <button className="p-4 rounded-full bg-red-500 hover:bg-red-600">
          <Phone className="w-6 h-6 text-white" />
        </button>
      </div>
    </div>
  );
}