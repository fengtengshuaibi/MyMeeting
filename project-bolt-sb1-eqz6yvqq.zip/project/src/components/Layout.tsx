import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import { Calendar, Users, Settings, Video } from 'lucide-react';

export function Layout() {
  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-20 bg-blue-700 flex flex-col items-center py-6 space-y-8">
        <Link to="/" className="text-white hover:text-blue-200">
          <Video className="w-8 h-8" />
        </Link>
        <nav className="flex flex-col space-y-6">
          <Link to="/meetings" className="text-white hover:text-blue-200">
            <Calendar className="w-6 h-6" />
          </Link>
          <Link to="/contacts" className="text-white hover:text-blue-200">
            <Users className="w-6 h-6" />
          </Link>
          <Link to="/settings" className="text-white hover:text-blue-200">
            <Settings className="w-6 h-6" />
          </Link>
        </nav>
      </aside>
      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}