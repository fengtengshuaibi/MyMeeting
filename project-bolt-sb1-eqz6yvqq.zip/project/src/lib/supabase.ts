import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
};

export type Meeting = {
  id: string;
  meeting_number: string;
  title: string | null;
  host_id: string;
  is_active: boolean;
  settings: {
    mute_on_join?: boolean;
    video_on_join?: boolean;
    waiting_room?: boolean;
  };
  created_at: string;
  started_at: string | null;
  ended_at: string | null;
};

export type MeetingParticipant = {
  id: string;
  meeting_id: string;
  user_id: string;
  joined_at: string;
  left_at: string | null;
};

export type Contact = {
  id: string;
  user_id: string;
  contact_id: string;
  created_at: string;
};