import React from 'react';
import { MeetingControls } from '../components/MeetingControls';
import { useMeetingStore } from '../store/meeting';

export function Meeting() {
  const { isVideoOn } = useMeetingStore();

  return (
    <div className="h-screen bg-gray-900 relative">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
        {/* Main video feed */}
        <div className="col-span-2 aspect-video bg-gray-800 rounded-lg overflow-hidden">
          {!isVideoOn ? (
            <div className="w-full h-full flex items-center justify-center">
              <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center">
                <span className="text-2xl text-white">用户</span>
              </div>
            </div>
          ) : (
            <div className="w-full h-full bg-black">
              {/* Video would be rendered here */}
            </div>
          )}
        </div>

        {/* Participant tiles */}
        {[1, 2, 3].map((i) => (
          <div key={i} className="aspect-video bg-gray-800 rounded-lg overflow-hidden">
            <div className="w-full h-full flex items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-gray-700 flex items-center justify-center">
                <span className="text-sm text-white">用户 {i}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <MeetingControls />
    </div>
  );
}