import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import { UserPlus, Trash2 } from 'lucide-react';
import type { Profile } from '../lib/supabase';

export function Contacts() {
  const { user } = useAuthStore();
  const [contacts, setContacts] = useState<Profile[]>([]);
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    const { data, error } = await supabase
      .from('contacts')
      .select('contact_id, profiles:contact_id(*)')
      .eq('user_id', user?.id);

    if (!error && data) {
      setContacts(data.map((contact) => contact.profiles));
    }
  };

  const addContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select()
        .eq('email', email)
        .single();

      if (profileError || !profile) {
        setError('未找到该用户');
        return;
      }

      const { error } = await supabase.from('contacts').insert({
        user_id: user?.id,
        contact_id: profile.id
      });

      if (error) {
        setError('添加联系人失败');
        return;
      }

      setEmail('');
      loadContacts();
    } catch (err) {
      setError('操作失败，请重试');
    }
  };

  const removeContact = async (contactId: string) => {
    const { error } = await supabase
      .from('contacts')
      .delete()
      .eq('user_id', user?.id)
      .eq('contact_id', contactId);

    if (!error) {
      loadContacts();
    }
  };

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-semibold mb-8">通讯录</h1>

        <form onSubmit={addContact} className="mb-8">
          <div className="flex gap-4">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="输入邮箱添加联系人"
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <UserPlus className="w-5 h-5" />
            </button>
          </div>
          {error && <p className="mt-2 text-red-600 text-sm">{error}</p>}
        </form>

        <div className="bg-white rounded-lg shadow">
          {contacts.length === 0 ? (
            <div className="p-4 text-gray-500">暂无联系人</div>
          ) : (
            <ul className="divide-y divide-gray-200">
              {contacts.map((contact) => (
                <li
                  key={contact.id}
                  className="flex items-center justify-between p-4"
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-medium">
                        {contact.display_name?.[0] || '用户'}
                      </span>
                    </div>
                    <div className="ml-4">
                      <p className="font-medium">
                        {contact.display_name || '未设置昵称'}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => removeContact(contact.id)}
                    className="text-gray-400 hover:text-red-600"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}