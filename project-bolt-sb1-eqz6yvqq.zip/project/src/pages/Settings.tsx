import React, { useState } from 'react';
import { useAuthStore } from '../store/auth';

export function Settings() {
  const { profile, updateProfile, signOut } = useAuthStore();
  const [displayName, setDisplayName] = useState(profile?.display_name || '');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      await updateProfile({
        id: profile?.id,
        display_name: displayName
      });
      setSuccess('个人信息已更新');
    } catch (err) {
      setError('更新失败，请重试');
    }
  };

  return (
    <div className="p-8">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl font-semibold mb-8">设置</h1>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-medium mb-6">个人信息</h2>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                昵称
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            {error && (
              <p className="text-red-600 text-sm mb-4">{error}</p>
            )}
            {success && (
              <p className="text-green-600 text-sm mb-4">{success}</p>
            )}
            <button
              type="submit"
              className="bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              保存
            </button>
          </form>

          <div className="mt-8 pt-8 border-t">
            <h2 className="text-xl font-medium mb-6">账号</h2>
            <button
              onClick={signOut}
              className="bg-red-600 text-white py-2 px-4 rounded hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              退出登录
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}