import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Video } from 'lucide-react';
import { useMeetingStore } from '../store/meeting';
import { supabase } from '../lib/supabase';
import type { Meeting } from '../lib/supabase';
import { format } from 'date-fns';

export function Home() {
  const navigate = useNavigate();
  const { createMeeting, joinMeeting } = useMeetingStore();
  const [recentMeetings, setRecentMeetings] = useState<Meeting[]>([]);
  const [meetingNumber, setMeetingNumber] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadRecentMeetings();
  }, []);

  const loadRecentMeetings = async () => {
    const { data } = await supabase
      .from('meetings')
      .select()
      .order('created_at', { ascending: false })
      .limit(5);

    if (data) {
      setRecentMeetings(data);
    }
  };

  const handleCreateMeeting = async () => {
    try {
      const meeting = await createMeeting();
      navigate('/meeting');
    } catch (err) {
      setError('创建会议失败，请重试');
    }
  };

  const handleJoinMeeting = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      await joinMeeting(meetingNumber);
      navigate('/meeting');
    } catch (err) {
      setError('加入会议失败，请检查会议号是否正确');
    }
  };

  return (
    <div className="p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-semibold mb-8">快速会议</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button
            onClick={handleCreateMeeting}
            className="flex items-center justify-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="text-center">
              <div className="bg-blue-100 p-4 rounded-full inline-block mb-4">
                <Video className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-lg font-medium">发起会议</h2>
              <p className="text-gray-500 mt-2">立即开始视频会议</p>
            </div>
          </button>

          <form
            onSubmit={handleJoinMeeting}
            className="flex items-center justify-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="text-center w-full">
              <div className="bg-green-100 p-4 rounded-full inline-block mb-4">
                <Plus className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-lg font-medium">加入会议</h2>
              <div className="mt-4">
                <input
                  type="text"
                  value={meetingNumber}
                  onChange={(e) => setMeetingNumber(e.target.value)}
                  placeholder="输入会议号"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                {error && <p className="mt-2 text-red-600 text-sm">{error}</p>}
                <button
                  type="submit"
                  className="mt-4 w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700"
                >
                  加入
                </button>
              </div>
            </div>
          </form>
        </div>

        <div className="mt-12">
          <h2 className="text-xl font-medium mb-4">最近会议</h2>
          <div className="bg-white rounded-lg shadow">
            {recentMeetings.length === 0 ? (
              <div className="p-4 text-gray-500">今天没有会议</div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {recentMeetings.map((meeting) => (
                  <li key={meeting.id} className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">
                          {meeting.title || '未命名会议'}
                        </p>
                        <p className="text-sm text-gray-500">
                          会议号：{meeting.meeting_number}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">
                          {format(
                            new Date(meeting.created_at),
                            'yyyy-MM-dd HH:mm'
                          )}
                        </p>
                        <button
                          onClick={() => joinMeeting(meeting.meeting_number)}
                          className="mt-2 text-blue-600 hover:text-blue-800"
                        >
                          重新加入
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}