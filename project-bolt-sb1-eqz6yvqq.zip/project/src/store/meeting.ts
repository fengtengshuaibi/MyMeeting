import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { Meeting, MeetingParticipant } from '../lib/supabase';

interface MeetingState {
  currentMeeting: Meeting | null;
  participants: MeetingParticipant[];
  isMuted: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  createMeeting: (title?: string) => Promise<Meeting>;
  joinMeeting: (meetingNumber: string) => Promise<void>;
  leaveMeeting: () => Promise<void>;
  toggleMute: () => void;
  toggleVideo: () => void;
  toggleScreenShare: () => void;
}

export const useMeetingStore = create<MeetingState>((set, get) => ({
  currentMeeting: null,
  participants: [],
  isMuted: false,
  isVideoOn: true,
  isScreenSharing: false,

  createMeeting: async (title) => {
    const { data, error } = await supabase.rpc('generate_meeting_number');
    if (error) throw error;

    const meetingNumber = data as string;
    const { data: meeting, error: createError } = await supabase
      .from('meetings')
      .insert({
        meeting_number: meetingNumber,
        title,
        host_id: (await supabase.auth.getUser()).data.user?.id,
        is_active: true,
        settings: {
          mute_on_join: false,
          video_on_join: true,
          waiting_room: false
        },
        started_at: new Date().toISOString()
      })
      .select()
      .single();

    if (createError) throw createError;
    set({ currentMeeting: meeting });
    return meeting;
  },

  joinMeeting: async (meetingNumber: string) => {
    const { data: meeting, error: meetingError } = await supabase
      .from('meetings')
      .select('*')
      .eq('meeting_number', meetingNumber)
      .single();

    if (meetingError) throw meetingError;

    const { error: joinError } = await supabase
      .from('meeting_participants')
      .insert({
        meeting_id: meeting.id,
        user_id: (await supabase.auth.getUser()).data.user?.id
      });

    if (joinError) throw joinError;
    set({ currentMeeting: meeting });
  },

  leaveMeeting: async () => {
    const { currentMeeting } = get();
    if (!currentMeeting) return;

    const { error } = await supabase
      .from('meeting_participants')
      .update({ left_at: new Date().toISOString() })
      .eq('meeting_id', currentMeeting.id)
      .eq('user_id', (await supabase.auth.getUser()).data.user?.id);

    if (error) throw error;
    set({ currentMeeting: null });
  },

  toggleMute: () => set((state) => ({ isMuted: !state.isMuted })),
  toggleVideo: () => set((state) => ({ isVideoOn: !state.isVideoOn })),
  toggleScreenShare: () => set((state) => ({ isScreenSharing: !state.isScreenSharing }))
}));

// Subscribe to meeting participants
supabase
  .channel('meeting_participants')
  .on(
    'postgres_changes',
    {
      event: '*',
      schema: 'public',
      table: 'meeting_participants'
    },
    async (payload) => {
      const { currentMeeting } = useMeetingStore.getState();
      if (!currentMeeting) return;

      const { data: participants, error } = await supabase
        .from('meeting_participants')
        .select('*')
        .eq('meeting_id', currentMeeting.id)
        .is('left_at', null);

      if (!error) {
        useMeetingStore.setState({ participants });
      }
    }
  )
  .subscribe();